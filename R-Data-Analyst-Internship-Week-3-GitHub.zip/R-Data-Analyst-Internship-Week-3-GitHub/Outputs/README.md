# Outputs

This folder is reserved for R console outputs, model summaries, and evaluation metrics generated when the script is executed in R/RStudio.
