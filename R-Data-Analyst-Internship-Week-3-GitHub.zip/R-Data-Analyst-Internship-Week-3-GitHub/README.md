# 📊 R Data Analyst Internship – Week 3

## Statistical Analysis and Predictive Modeling using R

This repository contains my Week 3 project for the Virtual R Data Analyst Internship.

### Objectives
- Perform exploratory statistical analysis
- Conduct hypothesis testing
- Test correlations and assumptions
- Build a multiple linear regression model
- Split data into training and testing sets
- Apply 5-fold cross-validation
- Evaluate RMSE, MAE and R²
- Perform regression diagnostics
- Interpret results and identify improvements

### Dataset
**Palmer Penguins** — a public dataset containing Adelie, Chinstrap and Gentoo penguins.

Source: https://github.com/allisonhorst/palmerpenguins

### Predictive Model
The target variable is `body_mass_g`. Predictors include:
- `flipper_length_mm`
- `bill_length_mm`
- `bill_depth_mm`

### Statistical Methods
1. `str()` and `summary()` for data inspection
2. Shapiro-Wilk normality test
3. Independent two-sample t-test for body mass by sex
4. Pearson correlation test for flipper length and body mass
5. 80:20 train-test split
6. Multiple linear regression
7. 5-fold cross-validation
8. RMSE, MAE and R² evaluation
9. Residual and actual-vs-predicted diagnostics

### Repository Structure
```text
R-Data-Analyst-Internship-Week-3/
├── README.md
├── R/
│   └── week3_statistical_predictive_modeling.R
├── Report/
│   └── R_Week3_Statistical_Predictive_Modeling_Report.docx
├── Data/
│   └── README.md
├── Visualizations/
│   ├── residual_plot.png
│   ├── actual_vs_predicted.png
│   └── cross_validation.png
└── Outputs/
    └── README.md
```

### How to Run
Install R and RStudio, then run:

```r
install.packages(c("tidyverse", "palmerpenguins", "caret"))
```

Open `R/week3_statistical_predictive_modeling.R` and run it from beginning to end.

### Potential Improvements
- Add species and sex as predictors
- Test interaction effects
- Test nonlinear relationships
- Compare Random Forest and other machine-learning models
- Investigate influential observations

### Internship
**Program:** Virtual R Data Analyst Internship  
**Task:** Week 3 – Statistical Analysis and Predictive Modeling using R

**Status:** Completed
