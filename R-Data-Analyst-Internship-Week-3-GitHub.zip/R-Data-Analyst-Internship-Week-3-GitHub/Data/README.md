# Data

The project uses the publicly available Palmer Penguins dataset through the `palmerpenguins` R package.

The dataset is loaded directly in R with:

```r
library(palmerpenguins)
data("penguins")
```

Source: https://github.com/allisonhorst/palmerpenguins
